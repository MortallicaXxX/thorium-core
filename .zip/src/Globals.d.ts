declare module "*.html";
declare module "*.css";