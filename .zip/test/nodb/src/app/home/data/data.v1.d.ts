export declare const data: {
    value: number;
    children: {
        name: string;
        children: ({
            name: string;
            value: number;
            children?: undefined;
        } | {
            name: string;
            children: {
                name: string;
                value: number;
            }[];
            value?: undefined;
        })[];
    }[];
};
