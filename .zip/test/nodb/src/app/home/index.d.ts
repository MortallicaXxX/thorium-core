import { NodeTemplate } from "../../../../../dist";
export declare const HomeView: (connectorTemplate?: import("../../../../../dist").ConnectorTemplate) => {
    localName: string;
    attr: Record<string, string>;
    childrens: NodeTemplate[];
    proto: Record<string, any>;
};
