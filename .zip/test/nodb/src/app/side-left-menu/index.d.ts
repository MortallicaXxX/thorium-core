import StickyLeftMenuSticky from '../side-left-menu-sticky';
export { StickyLeftMenuSticky };
export declare const SideLeftMenuStickyConnector: (connectorTemplate?: import("../../../../../dist").ConnectorTemplate) => {
    localName: string;
    attr: Record<string, string>;
    childrens: import("../../../../../dist").NodeTemplate[];
    proto: Record<string, any>;
};
declare const _default: () => {
    localName: string;
    attr: Record<string, string>;
    childrens: import("../../../../../dist").NodeTemplate[];
    proto: Record<string, any>;
};
export default _default;
