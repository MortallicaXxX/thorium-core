import Thorium, { Connector, DesignSystem, DOM, ThoriumController, PaternArea } from '../../../';
import useState from '/Users/guillaume/Documents/github/Types/States/src';
export declare const AppPage: import("../../../dist/design-system").CustomElementPatern;
import './style.css';
export { useState, Thorium, Connector, DesignSystem, DOM, ThoriumController, PaternArea };
