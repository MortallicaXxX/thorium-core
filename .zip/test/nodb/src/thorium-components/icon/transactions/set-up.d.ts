export declare const iconSetUp: {
    name: string;
    template: {
        proto: {
            setIcon: (iconPath: string) => void;
            setType: (icontype: string) => void;
        };
    };
};
