export declare const setType: {
    name: string;
    callback: (target: any, options: [string]) => void;
};
