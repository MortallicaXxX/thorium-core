export declare const setIcon: {
    name: string;
    callback: (target: any, options: [string]) => void;
};
