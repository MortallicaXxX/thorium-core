import Icon , { IconInitOptions } from './icon';

export { Icon as ThoriumIcon , IconInitOptions }