declare module "*.svg";
declare module "*.css";
declare module "*.module.css";