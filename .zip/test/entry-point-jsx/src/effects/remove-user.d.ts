export declare const removeUser: {
    name: string;
    callback: (target: Element, options: any) => void;
};
