export const removeUser = {
  name : 'remove-user',
  callback : (target:Element,options) => {
    alert('remove-user')
  }
}