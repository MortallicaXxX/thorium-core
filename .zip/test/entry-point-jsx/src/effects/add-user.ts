export const addUser = {
  name : 'add-user',
  callback : (target:Element,options) => {
    alert('add-user')
  }
}