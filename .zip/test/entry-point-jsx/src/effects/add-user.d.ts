export declare const addUser: {
    name: string;
    callback: (target: Element, options: any) => void;
};
