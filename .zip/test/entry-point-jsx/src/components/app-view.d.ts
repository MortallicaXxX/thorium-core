declare const ViewApp: import("../../../../dist").CustomElementPatern<unknown, unknown>;
export { ViewApp };
