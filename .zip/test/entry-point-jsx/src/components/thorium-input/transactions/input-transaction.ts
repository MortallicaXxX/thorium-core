export const InitInput = {
  name : 'init-input-transaction',
  template : {
    attr : {
      'area-hovered' : 'false',
      'area-selected' : 'false',
    }
  }
}