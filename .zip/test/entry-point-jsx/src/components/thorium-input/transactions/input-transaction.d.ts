export declare const InitInput: {
    name: string;
    template: {
        attr: {
            'area-hovered': string;
            'area-selected': string;
        };
    };
};
