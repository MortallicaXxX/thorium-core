export declare const AreaUnSelected: {
    name: string;
    callback: (element: any) => void;
};
