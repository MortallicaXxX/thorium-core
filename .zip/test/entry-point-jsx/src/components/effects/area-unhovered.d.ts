export declare const AreaUnHovered: {
    name: string;
    callback: (element: any) => void;
};
