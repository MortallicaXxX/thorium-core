export declare const AreaHovered: {
    name: string;
    callback: (element: any) => void;
};
