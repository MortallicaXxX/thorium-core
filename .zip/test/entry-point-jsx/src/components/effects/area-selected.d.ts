export declare const AreaSelected: {
    name: string;
    callback: (element: any) => void;
};
