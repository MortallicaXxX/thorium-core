export const init = {
  name : 'init-state',
  template : {
    proto : {
      onmousedown:null
    }
  }
}