export declare const buttonTransaction: {
    name: string;
    template: {
        proto: {
            onmousedown(event: any): void;
        };
    };
};
