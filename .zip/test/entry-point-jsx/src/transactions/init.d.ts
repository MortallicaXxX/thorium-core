export declare const init: {
    name: string;
    template: {
        proto: {
            onmousedown: null;
        };
    };
};
