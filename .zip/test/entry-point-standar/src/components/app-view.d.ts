declare const ViewApp: import("../../../../").CustomElementPatern<unknown, unknown>;
export { ViewApp };
