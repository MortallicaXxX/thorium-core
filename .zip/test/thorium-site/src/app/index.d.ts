export declare const App: () => any;
