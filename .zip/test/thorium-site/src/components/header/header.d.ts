import { CustomElement } from '../..';
export type THeader = CustomElement<HTMLDivElement, {}>;
export declare const Header: () => any;
