import { CustomElement, IViewController } from '../..';
export type TRightSideBar = CustomElement<HTMLDivElement, IViewController>;
export declare const RightSideBar: () => any;
