export declare const Content: () => any;
