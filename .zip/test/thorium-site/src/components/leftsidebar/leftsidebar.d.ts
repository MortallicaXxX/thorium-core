import { CustomElement, IViewController } from '../..';
export type TLeftSideBar = CustomElement<HTMLDivElement, IViewController>;
export declare const LeftSideBar: () => any;
