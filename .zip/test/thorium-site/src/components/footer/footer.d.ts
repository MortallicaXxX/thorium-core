import { CustomElement, IViewController } from '../..';
export type TFooter = CustomElement<HTMLDivElement, IViewController>;
export declare const Footer: () => any;
