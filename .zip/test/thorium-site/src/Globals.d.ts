declare module "*.css";
declare module "*.jpeg";
declare module "*.png";