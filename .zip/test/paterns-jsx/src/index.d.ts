export declare const inputPatern: any, Input: any;
